//
//  ViewController.swift
//  LoginViewCode-Curso
//
//  Created by Leonardo Lamoia on 06/10/22.
//

import UIKit
import Firebase

class LoginVC: UIViewController {
    
    var auth:Auth?
    
    var loginScreen:LoginScreen?
    
    var alert:Alert?
    
    override func loadView() {
        self.loginScreen = LoginScreen()
        self.view = self.loginScreen
    }
    
    // MARK: Adicionando nosso elemento e setando as constraints dele
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loginScreen?.delegate(delegate: self)
        self.loginScreen?.configTextFieldDelegate(delegate: self)
        self.auth = Auth.auth()
        self.alert = Alert(controller: self)
    }
  
    
    override func viewWillAppear(_ animated: Bool) {
        //setNavigatonBarHidden, para habilitar ou desabilitar a navigation (TopBar)
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
 
}

extension LoginVC:LoginScreenProtocol {
    func actionLoginButton() {
        
        
        
        guard let login = self.loginScreen else {return}

        self.auth?.signIn(withEmail: login.getEmail(), password: login.getPassword(), completion: { usuario, error in

            if error != nil{
                self.alert?.getAlert(titulo: "Atenção", mensagem: "Dados Incorretos, verifique e tente Novamente!!")
            }else{

                if usuario == nil{
                    self.alert?.getAlert(titulo: "Atenção", mensagem: "Tivemos um problema inesperado, tente novamente mais tarde!!")
                }else {
//                    self.alert?.getAlert(titulo: "Parabéns", mensagem: "Usuario logado com sucesso!!")
                    let VC = HomeVC()
                    let navVC = UINavigationController(rootViewController: VC)
                    navVC.modalPresentationStyle = .fullScreen
                    self.present(navVC, animated: true, completion: nil)
                }
            }
        })
    }
    
    func actionRegisterButton() {
        let vc:RegisterVC = RegisterVC()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

extension LoginVC:UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.loginScreen?.validaTextFields()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
